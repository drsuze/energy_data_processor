# energy_data_processor
This repository generates daily energy statistics and related visuals by aggregating time series power data.

# How to provide power time series and configuration inputs
Pending.

# How to export daily energy outputs
Pending.
